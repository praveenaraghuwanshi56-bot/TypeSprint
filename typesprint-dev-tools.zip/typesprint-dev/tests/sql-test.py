# Runs supabase-setup.sql against a real throw-away Postgres and exercises every account/leaderboard/admin function.
# Needs:  pip install pgserver
import pgserver, tempfile, json, sys
srv = pgserver.get_server(tempfile.mkdtemp(), cleanup_mode='delete')
def q(sql, fetch=True):
    return srv.psql(sql)
# Minimal Supabase-like environment
print(q("""create schema if not exists extensions; create role anon nologin; create role authenticated nologin;
create function extensions.gen_salt(t text) returns text language sql as $$ select '$s$' || substr(md5(random()::text), 1, 8) $$;
create function extensions.crypt(pw text, salt text) returns text language sql as $$ select substr(salt, 1, 11) || md5(substr(salt, 1, 11) || pw) $$;"""))
import os
HERE = os.path.dirname(os.path.abspath(__file__))
SQL_PATH = os.environ.get("TS_SQL") or os.path.join(HERE, "..", "..", "typesprint", "supabase-setup.sql")
# pgserver (the throw-away Postgres used here) has no pgcrypto, so the CREATE EXTENSION line is dropped
# and extensions.crypt / extensions.gen_salt are stubbed above. Real Supabase has the genuine pgcrypto.
sql = open(SQL_PATH).read().replace('create extension if not exists pgcrypto with schema extensions;','')
out = srv.psql(sql)
print("setup ran ok" if 'ERROR' not in out else "SETUP ERRORS:\n"+out)
out = srv.psql(sql)   # idempotent
print("re-run ok" if 'ERROR' not in out else "RERUN ERRORS:\n"+out)
def call(fn, args):
    r = srv.psql(f"select {fn}({args});")
    lines = [l.strip() for l in r.splitlines() if l.strip().startswith(('{','['))]
    return json.loads(lines[0]) if lines else r
def sh(s): return "'" + s.replace("'", "''") + "'"
print("admin wrong pw:", call("login", f"{sh('admin')},{sh('nope')}"))
a = call("login", f"{sh('admin')},{sh('rudsilver56')}"); print("admin login:", {k: (v if k != 'token' else v[:6]+'…') for k, v in a.items()})
print("check_session:", call("check_session", sh(a['token'])))
b = call("signup", f"{sh('Alice_1')},{sh('secret1')}"); print("signup:", b['username'], b['is_admin'])
print("dup signup:", call("signup", f"{sh('alice_1')},{sh('secret1')}"))
print("reserved:", call("signup", f"{sh('admin')},{sh('secret1')}"), "| bad name:", call("signup", f"{sh('a b')},{sh('secret1')}"), "| short pw:", call("signup", f"{sh('bobby')},{sh('abc')}"))
# single session: logging in again kicks the first token
b2 = call("login", f"{sh('alice_1')},{sh('secret1')}")
print("old token after 2nd login:", call("check_session", sh(b['token'])), "| new token:", call("check_session", sh(b2['token']))['ok'])
# lockout
for i in range(5): call("login", f"{sh('alice_1')},{sh('bad')}")
print("after 5 fails:", call("login", f"{sh('alice_1')},{sh('secret1')}"))
srv.psql("update public.players set locked_until=null, failed_attempts=0;")
# results + leaderboard
t = call("login", f"{sh('alice_1')},{sh('secret1')}")['token']
print("save:", call("save_result", f"{sh(t)}, {sh(json.dumps({'mode':'wordle','variant':'5','wpm':0,'accuracy':100,'errors':1,'duration_seconds':40.2,'score':500,'best_streak':3}))}::jsonb"))
print("save bad:", call("save_result", f"{sh(t)}, {sh(json.dumps({'mode':'nope','wpm':0,'accuracy':100,'errors':1,'duration_seconds':4}))}::jsonb"))
print("save guest:", call("save_result", f"{sh('garbage')}, {sh(json.dumps({'mode':'typing','wpm':50,'accuracy':99,'errors':1,'duration_seconds':40}))}::jsonb"))
at = call("login", f"{sh('admin')},{sh('rudsilver56')}")['token']
call("save_result", f"{sh(at)}, {sh(json.dumps({'mode':'wordle','variant':'5','wpm':0,'accuracy':100,'errors':0,'duration_seconds':20,'score':600,'best_streak':7}))}::jsonb")
call("save_result", f"{sh(t)}, {sh(json.dumps({'mode':'typing','variant':'x','wpm':60,'accuracy':80,'errors':9,'duration_seconds':40}))}::jsonb")
call("save_result", f"{sh(t)}, {sh(json.dumps({'mode':'typing','variant':'x','wpm':45,'accuracy':97,'errors':1,'duration_seconds':40}))}::jsonb")
print("wordle5 board:", call("leaderboard", f"'wordle','5','best_streak'"))
print("typing board (80% run ignored):", call("leaderboard", "'typing',null,'wpm'"))
print("wordle6 empty:", call("leaderboard", "'wordle','6','best_streak'"))
# admin-only tests
tests = json.dumps([{"title":"T","difficulty":"easy","category":"x","text":"The rain tapped softly on the window while the kettle began to sing."}])
print("non-admin add:", call("add_tests", f"{sh(t)}, {sh(tests)}::jsonb"))
r = call("add_tests", f"{sh(at)}, {sh(tests)}::jsonb"); print("admin add:", r)
tid = srv.psql("select id from public.custom_tests limit 1;").split("\n")[2].strip()
print("non-admin delete:", call("delete_test", f"{sh(t)}, '{tid}'"), "| admin delete:", call("delete_test", f"{sh(at)}, '{tid}'"))
# browser roles cannot touch tables directly
print(srv.psql("set role anon; select count(*) from public.players;").strip().splitlines()[-1:])
print(srv.psql("set role anon; select count(*) from public.results;").strip().splitlines()[-1:])
print(srv.psql("set role anon; select public._uid('x');").strip().splitlines()[-1:])
print("anon can read tests table:", "ERROR" not in srv.psql("set role anon; select count(*) from public.custom_tests;"))

print("\n--- account settings ---")
print("rename to reserved:", call("rename_account", f"{sh(t)},{sh('admin')}"))
print("rename bad name:", call("rename_account", f"{sh(t)},{sh('x')}"))
print("rename ok:", call("rename_account", f"{sh(t)},{sh('Alice_Two')}"))
print("login with new name:", call("login", f"{sh('alice_two')},{sh('secret1')}")['username'], "| old name now:", call("login", f"{sh('alice_1')},{sh('secret1')}"))
t = call("login", f"{sh('alice_two')},{sh('secret1')}")['token']
print("avatar ok:", call("set_avatar", f"{sh(t)},{sh('zebra')},{sh('#A9C7D8')}"))
print("avatar bad colour:", call("set_avatar", f"{sh(t)},{sh('Q')},{sh('blue')}"))
print("avatar emoji:", call("set_avatar", f"{sh(t)},{sh('🦊')},{sh('#e3a08f')}"))
print("login returns avatar:", {k: v for k, v in call("login", f"{sh('alice_two')},{sh('secret1')}").items() if k.startswith('avatar')})
t = call("login", f"{sh('alice_two')},{sh('secret1')}")['token']
call("set_avatar", f"{sh(t)},{sh('z')},{sh('#9db894')}")
print("leaderboard shows name + avatar:", call("leaderboard", "'wordle','5','best_streak'"))
print("avatar reset:", call("set_avatar", f"{sh(t)},null::text,null::text"))
print("admin cannot delete:", call("delete_account", f"{sh(call('login', sh('admin')+','+sh('rudsilver56'))['token'])},{sh('rudsilver56')}"))
print("delete wrong pw:", call("delete_account", f"{sh(t)},{sh('nope')}"))
print("delete ok:", call("delete_account", f"{sh(t)},{sh('secret1')}"))
print("session dead:", call("check_session", sh(t)), "| login dead:", call("login", f"{sh('alice_two')},{sh('secret1')}"))
print("their results removed:", srv.psql("select count(*) from public.results r where not exists (select 1 from public.players p where p.id=r.player_id) and r.mode='wordle';").strip().splitlines()[-2:])
print("anon can't call rename on garbage token:", call("rename_account", f"'zzz',{sh('whatever')}"))
