# TypeSprint dev tools (not part of the website)

These scripts check that `../typesprint/index.html` and `../typesprint/supabase-setup.sql` still work after you change them.
**Do not upload this folder to your host.** Only the `typesprint` folder is the site.

## One-time setup
```
npm install            # installs jsdom (a pretend browser) and css-tree (CSS syntax checker)
pip install pgserver   # only for the SQL test: a throw-away Postgres
```

## Run
```
npm test               # page tests (about 2 minutes)
npm run test:sql       # database tests on a real Postgres
```
Use `TS_HTML=/path/to/index.html` or `TS_SQL=/path/to/supabase-setup.sql` to test another copy.

## What each test covers
| File | Covers |
|---|---|
| `theme-test.js` | Every colour theme defines the same variables in light and dark; theme/mode menus; Sunset default; My runs button |
| `accounts-test.js` | Sign-in gate, guest, sign up, stay signed in, signed out when another device signs in, admin-only upload, account menu (rename/icon/delete), leaderboard dropdown, sidebar icon |
| `shortcuts-test.js` | Sunset default, lesson progress on My runs, AI shortcut buttons (copy + open) |
| `learn-test.js` | Typing run log and AI report, My runs downloads, Wordle/Blink reports, rhythm trainer, a full lesson |
| `sql-test.py` | Sign up/in, one session per account, lockout, rename/icon/delete, scores, leaderboard, admin-only uploads, browser cannot read tables |

## How the tests work (so you can write more)
* The page is loaded in **jsdom** with fake `matchMedia`, `fetch`, dialog, clipboard and download functions.
* A **fake Supabase** object answers the same function names the real database has (`login`, `save_result`, ...), following the same rules as the SQL.
* Keys are pressed by dispatching `keydown` events on `document`; text is typed by setting an `<input>` value and dispatching `input` (with `bubbles: true` when the page listens on a parent).
* Timings are real, so game tests wait with `sleep()`.
* jsdom cannot show visuals, so **layout, colours and animations must be checked by eye** in a real browser.
