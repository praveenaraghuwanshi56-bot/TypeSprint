const { JSDOM, VirtualConsole } = require("jsdom");
const html = require("fs").readFileSync(process.env.TS_HTML || require("path").join(__dirname, "..", "..", "typesprint", "index.html"), "utf8");
const errs = []; const vc = new VirtualConsole();
vc.on("jsdomError", (e) => { const m = String(e.detail || e.message); if (!/matchMedia|scrollTo/.test(m)) errs.push(m); });
// fake server that follows the SQL's rules
const users = new Map([["admin", { pw: "rudsilver56", admin: true, tok: null }]]); const rows = []; let n = 0;
const byTok = (t) => { for (const [name, u] of users) if (u.tok && u.tok === t) return [name, u]; return null; };
function server(name, a) {
  switch (name) {
    case "signup": { const u = a.uname.toLowerCase().trim(); if (!/^[a-z0-9_]{3,16}$/.test(u)) return { ok: false, error: "bad_username" }; if (a.pw.length < 6) return { ok: false, error: "bad_password" }; if (users.has(u)) return { ok: false, error: "taken" }; users.set(u, { pw: a.pw, admin: false, tok: "t" + ++n }); return { ok: true, token: users.get(u).tok, username: u, is_admin: false }; }
    case "login": { const u = users.get(a.uname.toLowerCase()); if (!u || u.pw !== a.pw) return { ok: false, error: "wrong" }; u.tok = "t" + ++n; return { ok: true, token: u.tok, username: a.uname.toLowerCase(), is_admin: u.admin, avatar_letter: u.av && u.av.l, avatar_color: u.av && u.av.c }; }
    case "check_session": { const f = byTok(a.tok); return f ? { ok: true, username: f[0], is_admin: f[1].admin, avatar_letter: f[1].av && f[1].av.l, avatar_color: f[1].av && f[1].av.c } : { ok: false, error: "not_signed_in" }; }
    case "logout": { const f = byTok(a.tok); if (f) f[1].tok = null; return { ok: true }; }
    case "save_result": { const f = byTok(a.tok); if (!f) return { ok: false, error: "not_signed_in" }; rows.push({ user: f[0], ...a.r }); return { ok: true }; }
    case "leaderboard": { const best = {}; rows.filter((r) => r.mode === a.p_mode && (!a.p_variant || r.variant === a.p_variant)).forEach((r) => { best[r.user] = Math.max(best[r.user] || 0, r[a.p_metric] || 0); }); return Object.entries(best).filter(([, v]) => v > 0).sort((x, y) => y[1] - x[1]).map(([username, value], i) => ({ rank: i + 1, username, value, avatar_letter: users.get(username) && users.get(username).av && users.get(username).av.l, avatar_color: users.get(username) && users.get(username).av && users.get(username).av.c })); }
    case "rename_account": { const f = byTok(a.tok); if (!f) return { ok: false, error: "not_signed_in" }; const u = a.new_name.toLowerCase(); if (!/^[a-z0-9_]{3,16}$/.test(u)) return { ok: false, error: "bad_username" }; if (users.has(u) && u !== f[0]) return { ok: false, error: "taken" }; users.set(u, f[1]); if (u !== f[0]) users.delete(f[0]); rows.forEach((r) => { if (r.user === f[0]) r.user = u; }); return { ok: true, username: u }; }
    case "set_avatar": { const f = byTok(a.tok); if (!f) return { ok: false, error: "not_signed_in" }; if (a.color && !/^#[0-9a-fA-F]{6}$/.test(a.color)) return { ok: false, error: "bad_color" }; f[1].av = { l: a.letter ? [...a.letter][0] : null, c: a.color ? a.color.toLowerCase() : null }; return { ok: true, avatar_letter: f[1].av.l, avatar_color: f[1].av.c }; }
    case "delete_account": { const f = byTok(a.tok); if (!f) return { ok: false, error: "not_signed_in" }; if (f[1].admin) return { ok: false, error: "admin_protected" }; if (f[1].pw !== a.pw) return { ok: false, error: "wrong" }; users.delete(f[0]); return { ok: true }; }
    case "add_tests": { const f = byTok(a.tok); return f && f[1].admin ? { ok: true, added: a.tests.length } : { ok: false, error: "forbidden" }; }
  }
}
function open(session) {
  const dom = new JSDOM(html, { runScripts: "dangerously", pretendToBeVisual: true, url: "http://localhost/", virtualConsole: vc,
    beforeParse(w) {
      w.matchMedia = () => ({ matches: false }); w.scrollTo = () => {}; w.Math.random = () => 0;
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
      w.fetch = async () => ({ ok: true, json: async () => [] });
      w.supabase = { createClient: () => ({ rpc: async (nm, a) => ({ data: server(nm, a), error: null }), from: () => ({ select: () => ({ order: async () => ({ data: [], error: null }) }) }) }) };
      if (session) w.localStorage.setItem("ts-session", session);
    } });
  return dom.window;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const $ = (w, s) => w.document.querySelector(s), vis = (w, id) => !w.document.getElementById(id).hidden;
const fill = (w, u, p) => { $(w, "#auth-user").value = u; $(w, "#auth-pass").value = p; };
(async () => {
  // ---- 1. first visit: gate, guest
  let w = open(); await sleep(200);
  console.log("1. first visit shows sign-in gate:", vis(w, "view-auth"), "| tabs shown:", [...w.document.querySelectorAll(".tabs a")].map((a) => a.textContent).join("/"));
  $(w, "#auth-guest").click(); await sleep(30);
  console.log("   guest: gate hidden:", !vis(w, "view-auth"), "| who:", $(w, "#acct-btn").getAttribute("aria-label"), "| admin link hidden:", $(w, "#admin-link").hidden, "| 'Add texts' link hidden:", $(w, "#lib-add").hidden);
  w.location.hash = "#upload"; await sleep(40); console.log("   guest opening #upload ->", vis(w, "view-home") ? "sent home" : "NOT blocked");
  w.location.hash = "#classic"; await sleep(30);
  const inp = $(w, "#type-input"), text = w.document.querySelector("#passage").textContent; inp.value = text; inp.dispatchEvent(new w.Event("input")); await sleep(50);
  console.log("   guest finishes a test ->", $(w, "#save-status").textContent);
  // ---- 2. sign up
  w.document.getElementById("results").removeAttribute("open"); $(w, "#acct-btn").click(); $(w, '[data-act="signin"]').click(); await sleep(20);
  $(w, '#auth-tabs [data-t="up"]').click(); fill(w, "Alice_1", "abc"); $(w, "#auth-go").click(); await sleep(50);
  console.log("2. short password error:", $(w, "#auth-msg").textContent);
  fill(w, "alice_1", "secret1"); $(w, "#auth-go").click(); await sleep(50);
  console.log("   signed up: gate hidden:", !vis(w, "view-auth"), "| who:", $(w, "#acct-btn").getAttribute("aria-label"), "| admin link hidden:", $(w, "#admin-link").hidden);
  $(w, "#acct-btn").click(); $(w, '[data-act="signout"]').click(); await sleep(30); $(w, '#auth-tabs [data-t="up"]').click(); fill(w, "alice_1", "secret1"); $(w, "#auth-go").click(); await sleep(50);
  console.log("   duplicate name:", $(w, "#auth-msg").textContent);
  $(w, '#auth-tabs [data-t="in"]').click(); fill(w, "alice_1", "wrongpw"); $(w, "#auth-go").click(); await sleep(50); console.log("   wrong password:", $(w, "#auth-msg").textContent);
  fill(w, "alice_1", "secret1"); $(w, "#auth-go").click(); await sleep(50);
  const saved = w.localStorage.getItem("ts-session"); console.log("   signed in again; session stored:", !!saved);
  // ---- 3. keep signed in on reload
  const w2 = open(saved); await sleep(250);
  console.log("3. reload: no gate:", !vis(w2, "view-auth"), "| who:", $(w2, "#acct-btn").getAttribute("aria-label"));
  // ---- 4. signing in on another device signs this one out
  server("login", { uname: "alice_1", pw: "secret1" });         // "another device"
  w2.dispatchEvent(new w2.Event("focus")); await sleep(80);
  console.log("4. other device signed in -> gate back:", vis(w2, "view-auth"), "| message:", $(w2, "#auth-msg").textContent, "| session cleared:", w2.localStorage.getItem("ts-session") === null);
  // ---- 5. admin
  fill(w2, "admin", "rudsilver56"); $(w2, "#auth-go").click(); await sleep(60);
  console.log("5. admin: who:", $(w2, "#acct-btn").getAttribute("aria-label"), "| admin link visible:", !$(w2, "#admin-link").hidden, "| 'Add texts' link visible:", !$(w2, "#lib-add").hidden);
  w2.location.hash = "#upload"; await sleep(40); console.log("   admin opens #upload:", vis(w2, "view-upload"), "| pin box gone:", !w2.document.getElementById("pin-input"));
  const ta = $(w2, "#paste"); ta.value = "title: One\ndifficulty: easy\ncategory: x\n---\nThe rain tapped softly on the window while the kettle began to sing."; ta.dispatchEvent(new w2.Event("input", { bubbles: true })); $(w2, "#upload-btn").click(); await sleep(60);
  console.log("   admin upload:", $(w2, "#up-msg").textContent);
  // ---- 6. wordle win -> leaderboard (signed-in player only)
  $(w2, "#acct-btn").click(); $(w2, '[data-act="signout"]').click(); await sleep(30); fill(w2, "alice_1", "secret1"); $(w2, "#auth-go").click(); await sleep(50);
  w2.location.hash = "#wordle"; await sleep(40);
  const WORDS = html.match(/const WORDLE_WORDS = \(([\s\S]*?)\)\.split/)[1].replace(/"\s*\+\s*"/g, "").replace(/^\s*"|"\s*$/g, "").replace(/\n\s*/g, "").split(" ");
  for (const c of WORDS.filter((x) => x.length === 5)[0]) w2.document.dispatchEvent(new w2.KeyboardEvent("keydown", { key: c, bubbles: true }));
  w2.document.dispatchEvent(new w2.KeyboardEvent("keydown", { key: "Enter", bubbles: true })); await sleep(5 * 280 + 400 + 5 * 100 + 1100);
  console.log("6. wordle result card:", $(w2, "#r-rating").textContent, "|", $(w2, "#save-status").textContent);
  w2.document.getElementById("results").removeAttribute("open");
  w2.location.hash = "#leaderboard"; await sleep(60); const sel = { options: w2.document.querySelectorAll("#lb-dd .dd-item") }; $(w2, "#lb-dd .dd-btn").click(); [...w2.document.querySelectorAll("#lb-dd .dd-item")].find((i) => i.dataset.id === "wordle5").click(); await sleep(60);
  console.log("   leaderboard boards:", sel.options.length, "| wordle5 rows:", [...w2.document.querySelectorAll("#lb-list li")].map((l) => l.textContent.replace(/\s+/g, " ")), "| my row highlighted:", !!$(w2, "#lb-list li.me"));
  // ---- 7. side panel: icon on the panel, icon outside when closed
  w2.location.hash = "#classic"; await sleep(40); const view = $(w2, "#view-type"), vis2 = (id) => !w2.document.getElementById(id).hidden;
  console.log("7. panel open by default:", view.classList.contains("nook-open"), "| first in layout:", $(w2, ".type-layout").firstElementChild.id, "| close icon is inside the panel:", !!$(w2, "#lib-panel #nook-close svg"), "| open icon outside panel:", !$(w2, "#lib-panel").contains($(w2, "#nook-toggle")));
  $(w2, "#nook-close").click(); console.log("   panel icon closes it:", !view.classList.contains("nook-open"), "| aria-expanded on open-icon:", $(w2, "#nook-toggle").getAttribute("aria-expanded"), "| remembered:", w2.localStorage.getItem("ts-nook"), "| panel inert:", $(w2, "#lib-panel").inert);
  $(w2, "#nook-toggle").click(); console.log("   outside icon reopens it:", view.classList.contains("nook-open"));
  // ---- 8. account menu
  $(w2, "#acct-btn").click(); await sleep(20);
  console.log("8. menu opens:", vis2("acct-menu"), "| items:", [...w2.document.querySelectorAll("#acct-menu .menu-item")].map((b) => b.textContent).join(", "));
  $(w2, '[data-act="rename"]').click(); $(w2, "#acct-name").value = "x"; $(w2, '[data-act="save-rename"]').click(); await sleep(40); console.log("   bad rename:", $(w2, "#acct-msg").textContent);
  $(w2, "#acct-name").value = "Alice_Two"; $(w2, '[data-act="save-rename"]').click(); await sleep(40);
  console.log("   renamed ->", $(w2, "#acct-btn").getAttribute("aria-label"), "| menu says:", $(w2, "#acct-msg").textContent, "| letter on icon:", $(w2, "#acct-btn").textContent, "| session name:", JSON.parse(w2.localStorage.getItem("ts-session")).username);
  $(w2, '[data-act="icon"]').click(); const letter = $(w2, "#acct-letter"); letter.value = "zebra"; letter.dispatchEvent(new w2.Event("input", { bubbles: true })); $(w2, '.sw[data-c="#a9c7d8"]').click();
  console.log("   icon preview:", $(w2, "#icon-prev .av").textContent, $(w2, "#icon-prev .av").style.background, "| swatch pressed:", $(w2, '.sw[data-c="#a9c7d8"]').getAttribute("aria-pressed"));
  $(w2, '[data-act="save-icon"]').click(); await sleep(40);
  console.log("   saved icon -> letter:", $(w2, "#acct-btn").textContent, "| colour:", $(w2, "#acct-btn").style.background, "| text colour readable:", $(w2, "#acct-btn").style.color, "|", $(w2, "#acct-msg").textContent);
  $(w2, '[data-act="icon"]').click(); const cc = $(w2, "#acct-color"); cc.value = "#222222"; cc.dispatchEvent(new w2.Event("input", { bubbles: true })); console.log("   custom dark colour flips text to:", $(w2, "#icon-prev .av").style.color);
  $(w2, '[data-act="reset-icon"]').click(); await sleep(40); console.log("   reset ->", $(w2, "#acct-btn").textContent, "(first letter of name again)|", $(w2, "#acct-msg").textContent);
  w2.document.body.click(); console.log("   outside click closes menu:", !vis2("acct-menu"));
  $(w2, "#acct-btn").click(); w2.document.dispatchEvent(new w2.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); console.log("   Escape closes menu:", !vis2("acct-menu"));
  // ---- 9. leaderboard dropdown + avatar in rows
  w2.location.hash = "#leaderboard"; await sleep(60); const dd = $(w2, "#lb-dd .dd-btn");
  console.log("9. dropdown label:", $(w2, ".dd-label").textContent, "| list hidden:", $(w2, ".dd-list").hidden, "| groups:", [...w2.document.querySelectorAll(".dd-group")].map((g) => g.textContent).join("/"), "| options:", w2.document.querySelectorAll(".dd-item").length);
  dd.click(); dd.dispatchEvent(new w2.KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true })); dd.dispatchEvent(new w2.KeyboardEvent("keydown", { key: "Enter", bubbles: true })); await sleep(60);
  console.log("   keyboard picks next board:", $(w2, ".dd-label").textContent, "| closed again:", $(w2, ".dd-list").hidden, "| old <select> gone:", !w2.document.querySelector("select"));
  dd.click(); [...w2.document.querySelectorAll("#lb-dd .dd-item")].find((i) => i.dataset.id === "wordle5").click(); await sleep(60);
  console.log("   row with avatar:", [...w2.document.querySelectorAll("#lb-list li")].map((l) => l.textContent.replace(/\s+/g, " ")), "| avatar in row:", !!$(w2, "#lb-list .av"));
  // ---- 10. guest menu, delete account
  $(w2, "#acct-btn").click(); $(w2, '[data-act="delete"]').click(); $(w2, "#acct-delpw").value = "wrong"; $(w2, '[data-act="confirm-delete"]').click(); await sleep(40); console.log("10. delete with wrong password:", $(w2, "#acct-msg").textContent);
  $(w2, "#acct-delpw").value = "secret1"; $(w2, '[data-act="confirm-delete"]').click(); await sleep(60);
  console.log("    deleted -> gate shown:", vis2("view-auth"), "|", $(w2, "#auth-msg").textContent, "| session cleared:", w2.localStorage.getItem("ts-session") === null, "| user gone from server:", !users.has("alice_two"));
  $(w2, "#auth-guest").click(); await sleep(20); $(w2, "#acct-btn").click(); console.log("    guest menu:", [...w2.document.querySelectorAll("#acct-menu .menu-item")].map((b) => b.textContent).join(", "), "| icon shows:", $(w2, "#acct-btn").textContent);
  fill(w2, "admin", "rudsilver56"); $(w2, '[data-act="signin"]').click(); fill(w2, "admin", "rudsilver56"); $(w2, "#auth-go").click(); await sleep(60);
  $(w2, "#acct-btn").click(); console.log("    admin menu has no Delete:", ![...w2.document.querySelectorAll("#acct-menu .menu-item")].some((b) => /Delete/.test(b.textContent)), "| items:", [...w2.document.querySelectorAll("#acct-menu .menu-item")].map((b) => b.textContent).join(", "));
  console.log("ERRORS:", errs.length ? errs : "none"); process.exit(0);
})();
