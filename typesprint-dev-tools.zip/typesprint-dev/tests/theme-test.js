const { JSDOM, VirtualConsole } = require("jsdom"), csstree = require("css-tree");
const html = require("fs").readFileSync(process.env.TS_HTML || require("path").join(__dirname, "..", "..", "typesprint", "index.html"), "utf8");
// ---- CSS: every colour theme defines the same variables in light and dark
const css = html.match(/<style>([\s\S]*?)<\/style>/)[1], ast = csstree.parse(css), sets = {};
csstree.walk(ast, { visit: "Rule", enter(r) { const sel = csstree.generate(r.prelude); if (!/data-palette/.test(sel)) return; sets[sel] = []; csstree.walk(r.block, { visit: "Declaration", enter(d) { sets[sel].push(d.property); } }); } });
const ids = ["blue", "cyan", "forest", "violet", "rose", "sunset", "slate"], want = sets[`:root[data-palette="blue"]`];
console.log("palette rules:", Object.keys(sets).length, "| every theme has light+dark:", ids.every((i) => sets[`:root[data-palette="${i}"]`] && sets[`:root[data-palette="${i}"][data-theme="dark"]`]),
  "| same", want.length, "variables everywhere:", Object.values(sets).every((s) => s.length === want.length && want.every((p) => s.includes(p))));
console.log("hard-coded accent text left in CSS:", (css.match(/#2b2118/g) || []).length, "(only the 2 definitions expected)", "| sidebar stops above My runs button:", /top:5\.25rem;bottom:4\.75rem/.test(css));
// ---- behaviour
const errs = []; const vc = new VirtualConsole(); vc.on("jsdomError", (e) => { const m = String(e.detail || e.message); if (!/scrollTo/.test(m)) errs.push(m); });
function open(opts = {}) {
  return new JSDOM(html, { runScripts: "dangerously", pretendToBeVisual: true, url: "http://localhost/", virtualConsole: vc,
    beforeParse(w) {
      w.matchMedia = (q) => ({ matches: /dark/.test(q) ? !!opts.dark : /max-width/.test(q) ? false : false, addEventListener() {} }); w.scrollTo = () => {}; w.fetch = async () => ({ ok: true, json: async () => [] });
      w.sessionStorage.setItem("ts-guest", "1"); Object.entries(opts.ls || {}).forEach(([k, v]) => w.localStorage.setItem(k, v));
    } }).window;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  let w = open({ dark: true }); await sleep(120); let d = w.document, $ = (s) => d.querySelector(s), $$ = (s) => [...d.querySelectorAll(s)], root = d.documentElement;
  console.log("1. browser says dark, nothing saved -> theme:", root.dataset.theme, "| palette:", root.dataset.palette);
  w = open({ dark: false, ls: { "ts-palette": "blue" } }); await sleep(120); d = w.document; $ = (s) => d.querySelector(s); $$ = (s) => [...d.querySelectorAll(s)]; root = d.documentElement;
  console.log("   browser light + saved Blue -> theme:", root.dataset.theme, "| palette:", root.dataset.palette);
  $("#palette-btn").click(); const menu = $("#theme-menu");
  console.log("2. menu open:", !menu.hidden, "| colour themes:", $$(".pal").length, "(", $$(".pal").map((b) => b.textContent).join(", "), ") | modes:", $$("[data-mode]").map((b) => b.textContent + (b.getAttribute("aria-pressed") === "true" ? "*" : "")).join("/"), "| Blue selected:", $('[data-pal="blue"]').getAttribute("aria-pressed"));
  $('[data-pal="rose"]').click(); console.log("   pick Rose ->", root.dataset.palette, "| saved:", w.localStorage.getItem("ts-palette"), "| menu stays open:", !menu.hidden, "| Rose marked:", $('[data-pal="rose"]').getAttribute("aria-pressed"));
  $('[data-mode="dark"]').click(); console.log("   pick Dark ->", root.dataset.theme, "| saved:", w.localStorage.getItem("ts-theme"));
  $('[data-mode="system"]').click(); console.log("   pick System ->", root.dataset.theme, "(browser is light) | saved choice cleared:", w.localStorage.getItem("ts-theme") === null);
  $("#theme-toggle").click(); console.log("   quick toggle ->", root.dataset.theme, "| System no longer selected:", $('[data-mode="system"]').getAttribute("aria-pressed"));
  d.dispatchEvent(new w.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); console.log("3. Escape closes:", menu.hidden);
  $("#palette-btn").click(); d.body.click(); console.log("   outside click closes:", menu.hidden);
  $("#palette-btn").click(); $("#acct-btn").click(); console.log("   opening account menu closes theme menu:", menu.hidden, "| account menu open:", !$("#acct-menu").hidden);
  $("#palette-btn").click(); console.log("   and the other way round:", $("#acct-menu").hidden && !menu.hidden);
  const fab = $("#runs-fab"); console.log("4. My runs button:", fab.textContent.trim(), "->", fab.getAttribute("href"), "| footer link gone:", !$$(".foot a").some((a) => /My runs/.test(a.textContent)));
  w.location.hash = "#history"; await sleep(40); console.log("   current page marked:", fab.getAttribute("aria-current"));
  console.log("ERRORS:", errs.length ? errs : "none"); process.exit(0);
})();
