const { JSDOM, VirtualConsole } = require("jsdom");
const html = require("fs").readFileSync(process.env.TS_HTML || require("path").join(__dirname, "..", "..", "typesprint", "index.html"), "utf8");
const errs = []; const vc = new VirtualConsole();
vc.on("jsdomError", (e) => { const m = String(e.detail || e.message); if (!/matchMedia|scrollTo/.test(m)) errs.push(m); });
const downloads = []; let lastBlob = null;
const dom = new JSDOM(html, { runScripts: "dangerously", pretendToBeVisual: true, url: "http://localhost/", virtualConsole: vc,
  beforeParse(w) {
    w.matchMedia = () => ({ matches: false }); w.scrollTo = () => {}; w.Math.random = () => 0; w.confirm = () => true;
    w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
    w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); this.dispatchEvent(new w.Event("close")); };
    w.Blob = class { constructor(parts, o) { this.text = parts.join(""); this.type = o && o.type; } };
    w.URL.createObjectURL = (b) => { lastBlob = b; return "blob:test"; }; w.URL.revokeObjectURL = () => {};
    w.HTMLAnchorElement.prototype.click = function () { downloads.push({ name: this.download, text: lastBlob.text, type: lastBlob.type }); };
    w.fetch = async () => ({ ok: true, json: async () => [] });
  } });
const w = dom.window, d = w.document, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), $ = (s) => d.querySelector(s), $$ = (s) => [...d.querySelectorAll(s)];
const vis = (id) => !d.getElementById(id).hidden, go = async (h) => { w.location.hash = h; await sleep(40); };
const key = (k) => d.dispatchEvent(new w.KeyboardEvent("keydown", { key: k, bubbles: true }));
(async () => {
  await sleep(150); $("#auth-guest").click(); await sleep(20);
  console.log("1. nav:", $$(".tabs a").map((a) => a.textContent).join("/"), "| home cards:", $$("#view-home .card").length);
  // ---- typing test with a deliberate mistake + backspace
  await go("#classic"); const inp = $("#type-input"), text = $("#passage").textContent; let typed = "";
  for (let i = 0; i < text.length; i++) {
    if (i === 5) { inp.value = typed + "x"; inp.dispatchEvent(new w.Event("input")); await sleep(8); inp.value = typed; inp.dispatchEvent(new w.Event("input")); await sleep(8); }
    typed += text[i]; inp.value = typed; inp.dispatchEvent(new w.Event("input")); await sleep(8);
  }
  await sleep(60);
  console.log("2. result card open:", $("#results").hasAttribute("open"), "| guest note:", $("#save-status").textContent.slice(0, 40), "| tip:", $("#r-tip").textContent.slice(0, 60));
  $("#r-report").click(); $("#r-json").click();
  const md = downloads[0], js = downloads[1], raw = JSON.parse(js.text);
  console.log("   downloads:", md.name, md.type, "|", js.name, js.type);
  console.log("   report has sections:", ["Instructions for the AI", "## Speed and rhythm", "## Weakest keys", "## By finger", "## By keyboard row", "Definitions"].map((s) => md.text.includes(s)).join(","));
  console.log("   raw json: events", raw.events.length, "| keystroke row sample:", JSON.stringify(raw.events[0]), "| backspace logged:", raw.events.some((e) => e[1] === "b"), "| mistake logged:", raw.events.some((e) => e[1] === "k" && e[2] !== e[3]), "| analysis keys:", Object.keys(raw.analysis).length, "| accuracy:", raw.summary.accuracy, "| player:", raw.player);
  console.log("   confusion captured:", JSON.stringify(raw.analysis.confusions[0]), "| fingers:", Object.keys(raw.analysis.fingers).length, "| text included:", raw.context.text.length > 100);
  $("#r-close").click();
  // ---- history page
  await go("#history"); console.log("3. history rows:", $$("#h-list li").length, "| first:", $("#h-list li").textContent.replace(/\s+/g, " ").slice(0, 60));
  $('#h-list [data-dl="md"]').click(); $("#h-progress").click();
  console.log("   run report + progress report downloaded:", downloads[2].name.endsWith(".md"), downloads[3].name, "| progress has runs table:", downloads[3].text.includes("## Runs") && downloads[3].text.includes("Most-missed keys"));
  $("#h-all").click(); console.log("   all-runs json:", JSON.parse(downloads[4].text).runs.length, "run(s)");
  // ---- wordle (win) report
  await go("#wordle"); const WORDS = html.match(/const WORDLE_WORDS = \(([\s\S]*?)\)\.split/)[1].replace(/"\s*\+\s*"/g, "").replace(/^\s*"|"\s*$/g, "").replace(/\n\s*/g, "").split(" ");
  for (const c of WORDS.filter((x) => x.length === 5)[0]) key(c); key("Enter"); await sleep(5 * 280 + 400 + 5 * 100 + 1100);
  $("#r-report").click(); const wr = downloads.at(-1);
  console.log("4. wordle report:", wr.name, "| answer+marks table:", wr.text.includes("Answer:") && wr.text.includes("GGGGG"), "| no typing sections:", !wr.text.includes("By finger"));
  $("#r-close").click();
  // ---- balloons: logging hooks run without errors
  await go("#balloons"); $("#start-game").click(); await sleep(700); const word = $(".balloon .b-body").textContent; const gi = $("#game-input"); gi.value = "q"; gi.dispatchEvent(new w.Event("input")); gi.value = word; gi.dispatchEvent(new w.Event("input")); await sleep(50);
  console.log("5. balloon popped, score:", $("#g-score").textContent);
  await go("#cafe"); $("#start-cafe").click(); await sleep(500); const ci = $("#cafe-input"); ci.value = "zzz"; ci.dispatchEvent(new w.Event("input")); ci.value = $(".cust .order").textContent; ci.dispatchEvent(new w.Event("input")); await sleep(50);
  console.log("   cafe served, score:", $("#c-score").textContent);
  // ---- blink: three misses -> game report
  await go("#blink"); $("#start-blink").click();
  for (let r = 0; r < 3; r++) { await sleep(r === 0 ? 2700 : 2700); const bi = $("#blink-input"); bi.value = "zzzzzzzz"; bi.dispatchEvent(new w.Event("input")); await sleep(1450); }
  await sleep(100);
  console.log("6. blink ended:", $("#results").hasAttribute("open")); $("#r-report").click(); const br = downloads.at(-1);
  console.log("   blink report:", br.text.includes("Accuracy by word length") && br.text.includes("Mistakes"), "| events:", (br.text.match(/Words shown \| (\d+)/) || [])[1]); $("#r-close").click();
  // ---- learn page, rhythm trainer, tips
  await go("#learn"); console.log("7. lessons:", $$(".lesson-card").length, "| tips:", $$(".tip-card").length, "| tip of the day:", $("#tip-day").textContent.slice(0, 50), "| active tab:", $(".tabs a[aria-current=page]").textContent);
  $("#rh-start").click(); console.log("   rhythm dot animating:", $("#rh-dot").classList.contains("beat"), "| duration:", $("#rh-dot").style.animationDuration);
  for (let i = 0; i < 16; i++) { $("#rh-tap").dispatchEvent(new w.Event("pointerdown", { bubbles: true, cancelable: true })); await sleep(5); }
  console.log("   rhythm result:", $("#rh-msg").textContent.slice(0, 90), "| marks drawn:", $$("#rh-marks i").length, "| animation stopped:", !$("#rh-dot").classList.contains("beat"));
  // ---- lesson: demo then practice
  $(".lesson-card").click(); await sleep(40);
  console.log("8. lesson page:", $("#ls-title").textContent, "| home keys lit:", $$(".key.in").length, "| 'q' dimmed:", !$('[data-k="q"]').classList.contains("in"), "| hands:", $$(".finger").length, "| keys:", $$(".key").length);
  $("#ls-demo").click(); await sleep(30); console.log("   demo caption:", $("#ls-caption").textContent, "| key hot:", !!$(".key.hot"), "| finger raised:", !!$(".finger.on"));
  await sleep(1000); console.log("   demo moves on:", $("#ls-caption").textContent);
  $("#ls-start").click(); key("1"); console.log("   wrong key counted:", $("#ls-err").textContent, "| prompt shakes:", $("#ls-prompt").classList.contains("shake"));
  for (let guard = 0; guard < 600; guard++) {
    const cap = $("#ls-caption").textContent; if (cap.startsWith("Lesson complete") || cap.includes("need 85%")) break;
    const tiles = $$("#ls-prompt .ls-ch"), cur = tiles.findIndex((t) => t.classList.contains("cur"));
    if (cur < 0) { await sleep(30); continue; }
    key(tiles[cur].textContent.toLowerCase()); await sleep(cur === tiles.length - 1 ? 260 : 4);
  }
  console.log("   finished:", $("#ls-caption").textContent, "| saved:", Object.keys(JSON.parse(w.localStorage.getItem("ts-lessons") || "{}")), "| next button:", !$("#ls-next").hidden);
  $("#ls-next").click(); await sleep(30); console.log("   next lesson:", $("#ls-title").textContent, "| lit keys:", JSON.stringify($$(".key.in").map((k) => k.dataset.k).join("")));
  // ---- account menu has My runs
  $("#acct-btn").click(); console.log("9. guest menu:", $$("#acct-menu .menu-item").map((b) => b.textContent).join(", "));
  console.log("ERRORS:", errs.length ? errs : "none"); process.exit(0);
})();
